clc
clear all
close all
data_path = {'D:\BaiduNetdisk\download\XJTU-SY_Bearing_Datasets\Data\XJTU-SY_Bearing_Datasets\40Hz10kN\Bearing3_1\'};
% 初始化结果矩阵
train = [];
a = [];
b = [];
test = [];
% 定义要截取n个csv文件的数据
n=50;
for j = 1:length(data_path)
    % 获取文件夹中所有的csv文件
    fileList = dir(fullfile(data_path{j}, '*.csv'));
    fileNames = {fileList.name};  % 提取文件名

    % 对文件名进行自然排序
    sortedFileNames = sort_nat(fileNames);
    % 求出一共多少个文件
    List_length = length(sortedFileNames);
    % 逐个按照排序后的文件名提取csv表格中的数据
    for i = 1:List_length
        % 读取csv文件
        data = xlsread(fullfile(data_path{j}, sortedFileNames{i}));
        % 训练集数据 只选择第一列前1000个数据
        if j == 1 && i <= n
            if size(data, 1) >= 1000
                selectedData = data(2:1001, 1);
            else
                selectedData = data(:, 1);
            end
            % 将数据添加到结果矩阵中
            train = [train; selectedData'];
            disp(['提取 ', sortedFileNames{i}, ' 作为训练集']);
        end
        % 测试集前200个无故障的数据
       if j == 1 && i <= n
            if size(data, 1) >= 200
                selectedData = data(2:201, 1);
            else
                selectedData = data(:, 1);
            end
            % 将数据添加到结果矩阵中
            a = [a; selectedData'];
            disp(['提取 ', sortedFileNames{i}, ' 作为测试集']);
       end
       % 测试集后800个有故障的数据
       if j == 1 &&(i > (List_length-n-1) && i < List_length)
            % 测试集数据
            % 后20个文件的第一列前800个数据
            if size(data, 1) >= 800
                selectedData = data(2:801, 1);
            else
                selectedData = data(:, 1);
            end
            % 将数据添加到结果矩阵中
            b = [b; selectedData'];
            disp(['提取 ', sortedFileNames{i}, ' 作为测试集']);
       end
    end
end
% disp(a);
% disp(b);
test = [a,b];
% 平移矩阵使最小值为0
min_value = min(train);
xjtu_train = train - min_value;
save('xjtu_train.mat', 'xjtu_train');
min_value = min(test);
xjtu_test = test - min_value;
save('xjtu_test.mat', 'xjtu_test');