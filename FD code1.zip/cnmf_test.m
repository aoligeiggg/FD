%%
    d01=importdata('d01_te.dat');
    VT=d01;%将d01保存到变量XT((测试集) 52*900
    X=V';% 52*500
    XT=VT;% 52*960
    disp (size(W,1));
    disp (size(H,1));
%% cg重构
     Hn= (pinv(W' * W))* W' * X;%Hn为重构的矩阵
     Xn= W * Hn;%52*500
%     disp(size(Xn,2));
%%
for i=1:size(X,2)
    t2(i) = transpose(Hn(:,i)) * H(:,i);%计算训练样本的异常指标，用于求控制限
    SPE(i) = transpose(X(:,i) - Xn(:,i)) * (X(:,i) - Xn(:,i));
end

% disp(size(W,2));
%% Compute Control limit of SPE and T2 计算控制限

    [bandwidth,density,xmesh,cdf]=kde(t2); %计算t2的控制限
    r=0.99;
    for i=1:size(cdf,1),
        if cdf(i,1)>=r,
            break;
        end;
    end;
    T2limit=xmesh(i);
    
    [bandwidth,density,xmesh,cdf]=kde(SPE); % 计算spe的控制限
    r=0.99;
    for i=1:size(cdf,1),
        if cdf(i,1)>=r,
            break;
        end;
    end;
    SPElimit= xmesh(i);
%% 固定W更新H
H = abs(randn(rank,size(VT,2)));
    % main loop
    while true
        
        % check stop condition
        [stop_flag, reason, max_reached_flag] = check_stop_condition(epoch, infos, options);
        if stop_flag
            display_stop_reason(epoch, infos, options, method_name, reason, max_reached_flag);
            break;
        end
        
        ApW = Ap * W;
        AnW = An * W;
        WH  = W * H;
   
        % update H
        H = H .* sqrt((ApW' + AnW' * WH) ./ (AnW' + ApW' * WH));
        H = max(H, eps);
        HHt = H * H';

%         % update W
%         W = W .* sqrt((Ap * H' + AnW * HHt) ./ (An * H' + ApW * HHt)); 
%         W = max(W, eps);

        % measure gradient calc count
        grad_calc_count = grad_calc_count + m*n;

        % measure elapsed time
        elapsed_time = toc(start_time);        

        % update epoch
        epoch = epoch + 1;        
        
        % store info    
        infos = store_nmf_info(X, W, H, [], options, infos, epoch, grad_calc_count, elapsed_time);          
     
        % display info
        display_info(method_name, epoch, infos, options);

    end  
%% cg重构
     Hne= (pinv(W' * W))* W' * XT;%Hne为固定W后重构的矩阵  
     Xne= W * Hne;%52*960
     %disp(size(Hne,1));
for i=1:size(XT,2)% i = 1:960
    XTt2(i) = transpose(Hne(:,i)) * Hne(:,i);%计算测试样本的异常指标 ***Hn的问题
    XTSPE(i) = transpose(XT(:,i) - Xne(:,i)) * (XT(:,i) - Xne(:,i));
end

%% Plot the results 绘制测试图形
figure(12)

subplot(2,1,1);
plot(1:happen,XTt2(1:happen),'b',happen+1:size(XTt2,2),XTt2(happen+1:end),'b');%绘制T2的值
hold on;
TS=T2limit*ones(size(XT,2),1);
plot(TS,'k--'); % 绘制控制限
title('测试集T2 for TE data');
xlabel('Sample');
ylabel('T2');
hold off;

subplot(2,1,2);
plot(1:happen,XTSPE(1:happen),'b',happen+1:size(XTSPE,2),XTSPE(happen+1:end),'b');%绘制SPE
hold on;
S=SPElimit*ones(size(XT,2),1);
plot(S,'k--');%绘制控制限
title('SPE for TE data');
xlabel('Sample');
ylabel('SPE');
hold off;


%% False alarm rate
falseT2=0;
falseSPE=0;
for wi=1:happen
    if XTt2(wi)>T2limit
        falseT2=falseT2+1;
    end
    falserate_DGE_T2=100*falseT2/happen;
    if XTSPE(wi)>SPElimit
        falseSPE=falseSPE+1;
    end
    falserate_DGE_SPE=100*falseSPE/happen;
end

%% Miss alarm rate and False alarm rate 计算误警率和漏警率
missT2=0;
missSPE=0;
for wi=happen+1:size(XTt2,2)
    if XTt2(wi)<T2limit
        missT2=missT2+1;
    end
    if XTSPE(wi)<SPElimit
        missSPE=missSPE+1;
    end 
end
missrate_DGE_T2=100*missT2/(size(XTt2,2)-happen);
missrate_DGE_SPE=100*missSPE/(size(XTt2,2)-happen);
 disp('----False alarm rate----');
falserate_DGE = [falserate_DGE_T2 falserate_DGE_SPE]
 disp('----Miss alarm rate----');
missrate_DGE = [missrate_DGE_T2 missrate_DGE_SPE]
% % toc
% 
% %% Detection time 计算检测时间和运行时间
% i1=happen+1;
% while i1<=size(X,1)
%    T2_mw(i1,:)=XTt2(1,i1:(i1+5))-T2limit*ones(1,6);
%    flag1=0;
%    for j1=1:6
%        if T2_mw(i1,j1)<0
%            flag1=1;
%            i1=i1+j1;
%            break;
%        end
%    end
%    if flag1==0
%        detection_time_T2=i1;
%        break;
%    end
% end
% i2=happen+1;
% while i2<=size(X,1)
%     SPE_mw(i2,:)= XTSPE(1,i2:(i2+5))-SPElimit*ones(1,6);
%     flag2=0;
%     for j2=1:6
%        if SPE_mw(i2,j2)<0
%            flag2=1;
%            i2=i2+j2;
%            break;
%        end
%    end
%    if flag2==0
%        detection_time_SPE=i2;
%        break;
%    end
% end
% detection_time_T2
% detection_time_SPE
% runtime=toc 
