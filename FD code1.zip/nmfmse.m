function nmfmse( V, rdim, fname, showflag )
%Ŀ�꺯��Ϊŷ�Ͼ��� non-negative matrix factorization with mean squared error �������
load('xjtu_train.mat');
load('xjtu_test.mat');
V = xjtu_train;
VT = xjtu_test;

% d00=importdata('d00.dat'); % ��������
% d01=importdata('d01_te.dat');
% xx_train=d00';  %��d00��ת�ñ��浽����X��ѵ������52*500
% xx_test=d01;  %��d01���浽����XT((���Լ�) 52*900
%%
% Check that we have non-negative data
if min(V(:))<0, error('Negative values in data!'); end
% % Globally rescale data to avoid potential overflow/underflow
% V = V/max(V(:));

% Dimensions
vdim = size(V,1);
samples = size(V,2);
showflag= 1;
rdim =5;  
iterations = 500;
happen = 160;
% Create initial matrices ��ʼ������
W = abs(randn(vdim,rdim));
H = abs(randn(rdim,samples));
% Initialize displays
if showflag,
   figure(2); clf; % this will show the energies and sparsenesses
   figure(1); clf; % this will show the objective function
   drawnow;
end

% Calculate initial objective
objhistory = 0.5*sum(sum((V-W*H).^2));

timestarted = clock;

% Start iteration
iter = 0;
while iter<iterations,
    % Show progress
    fprintf('[%d]: %.5f \n',iter,objhistory(end));    
    % Save every once in a while
    if rem(iter,5)==0,
	elapsed = etime(clock,timestarted);
	fprintf('Saving...');
	save('results.mat','W','H','iter','objhistory','elapsed');
	fprintf('Done!\n');
    end
	
    % Show stats
    if showflag && (rem(iter,5)==0),
	figure(2);
	cursW = (sqrt(vdim)-(sum(W)./sqrt(sum(W.^2))))/(sqrt(vdim)-1);%����Wÿ�е�Ȩ��
	cursH = (sqrt(samples)-(sum(H')./sqrt(sum(H'.^2))))/(sqrt(samples)-1);%����Hÿ�е�Ȩ��
	subplot(3,1,1); bar(sqrt(sum(W.^2)));
	subplot(3,1,2); bar(cursW);
	subplot(3,1,3); bar(cursH);
	if iter>1,
	    figure(1);
	    plot(objhistory(3:end));
	end
	drawnow;
    end
    
    % Update iteration count
    iter = iter+1;    
    
    % Save old values
    Wold = W;
    Hold = H;
    
    % Compute new W and H (Lee and Seung; NIPS*2000) ���¹�ʽ
    H = H.*(W'*V)./(W'*W*H + 1e-9);
    W = W.*(V*H')./(W*H*H' + 1e-9);

    % Renormalize so rows of H have constant energy
   norms = sqrt(sum(H'.^2));      % norms ��һ���������洢�˾���Hÿһ�е�L2����
    H = H./(norms'*ones(1,samples));
    W = W.*(ones(vdim,1)*norms);
    % Calculate objective
    newobj = 0.5*sum(sum((V-W*H).^2));
    objhistory = [objhistory newobj];
end

    %%
    X=V;% 52*500
    XT=VT;% 52*960
%% cg�ع�
     Hn= (pinv(W' * W))* W' * X;%HnΪ�ع��ľ���
     Xn= W * Hn;%52*500
%     disp(size(Xn,2));
%%
for i=1:size(X,2)
    t2(i) = transpose(Hn(:,i)) * H(:,i);%����ѵ���������쳣ָ�꣬�����������
    SPE(i) = transpose(X(:,i) - Xn(:,i)) * (X(:,i) - Xn(:,i));
end

% disp(size(W,2));
%% Compute Control limit of SPE and T2 ���������

    [bandwidth,density,xmesh,cdf]=kde(t2); %����t2�Ŀ�����
    r=0.99;
    for i=1:size(cdf,1),
        if cdf(i,1)>=r,
            break;
        end;
    end;
    T2limit=xmesh(i);
    
    [bandwidth,density,xmesh,cdf]=kde(SPE); % ����spe�Ŀ�����
    r=0.99;
    for i=1:size(cdf,1),
        if cdf(i,1)>=r,
            break;
        end;
    end;
    SPElimit= xmesh(i);
%% �̶�W����H

H = abs(randn(rdim,size(VT,2)));
disp(size(H,1));
while iter<iterations,
%     % Update iteration count
%     iter = iter+1;    
%     
%     % Save old values
%     Wold = W;
%     Hold = H;
%     

    % Compute new W and H (Lee and Seung; NIPS*2000) ���¹�ʽ
    H = H.*(W'*VT)./(W'*W*H + 1e-9);
   
    % W = W.*(V*H')./(W*H*H' + 1e-9);

    % Renormalize so rows of H have constant energy
    % Calculate objective
    newobj = 0.5*sum(sum((VT-W*H).^2));
    objhistory = [objhistory newobj];
end

%% cg�ع�
     Hne= (pinv(W' * W))* W' * XT;%HneΪ�̶�W���ع��ľ���  
     Xne= W * Hne;%52*960
     %disp(size(Hne,1));
for i=1:size(XT,2)% i = 1:960
    XTt2(i) = transpose(Hne(:,i)) * Hne(:,i);%��������������쳣ָ�� ***Hn������
    XTSPE(i) = transpose(XT(:,i) - Xne(:,i)) * (XT(:,i) - Xne(:,i));
end

%% Plot the results ���Ʋ���ͼ��
figure(12)

subplot(2,1,1);
plot(1:happen,XTt2(1:happen),'b',happen+1:size(XTt2,2),XTt2(happen+1:end),'b');%����T2��ֵ
hold on;
TS=T2limit*ones(size(XT,2),1);
plot(TS,'k--'); % ���ƿ�����
title('���Լ�T2 for TE data');
xlabel('Sample');
ylabel('T2');
hold off;

subplot(2,1,2);
plot(1:happen,XTSPE(1:happen),'b',happen+1:size(XTSPE,2),XTSPE(happen+1:end),'b');%����SPE
hold on;
S=SPElimit*ones(size(XT,2),1);
plot(S,'k--');%���ƿ�����
title('SPE for TE data');
xlabel('Sample');
ylabel('SPE');
hold off;


%% False alarm rate
falseT2=0;
falseSPE=0;
for wi=1:happen
    if XTt2(wi)>T2limit
        falseT2=falseT2+1;
    end
    falserate_DGE_T2=100*falseT2/happen;
    if XTSPE(wi)>SPElimit
        falseSPE=falseSPE+1;
    end
    falserate_DGE_SPE=100*falseSPE/happen;
end

%% Miss alarm rate and False alarm rate �������ʺ�©����
missT2=0;
missSPE=0;
for wi=happen+1:size(XTt2,2)
    if XTt2(wi)<T2limit
        missT2=missT2+1;
    end
    if XTSPE(wi)<SPElimit
        missSPE=missSPE+1;
    end 
end
missrate_DGE_T2=100*missT2/(size(XTt2,2)-happen);
missrate_DGE_SPE=100*missSPE/(size(XTt2,2)-happen);
 disp('----False alarm rate----');
falserate_DGE = [falserate_DGE_T2 falserate_DGE_SPE]
 disp('----Miss alarm rate----');
missrate_DGE = [missrate_DGE_T2 missrate_DGE_SPE]
end
% % toc
% 
% %% Detection time ������ʱ�������ʱ��
% i1=happen+1;
% while i1<=size(X,1)
%    T2_mw(i1,:)=XTt2(1,i1:(i1+5))-T2limit*ones(1,6);
%    flag1=0;
%    for j1=1:6
%        if T2_mw(i1,j1)<0
%            flag1=1;
%            i1=i1+j1;
%            break;
%        end
%    end
%    if flag1==0
%        detection_time_T2=i1;
%        break;
%    end
% end
% i2=happen+1;
% while i2<=size(X,1)
%     SPE_mw(i2,:)= XTSPE(1,i2:(i2+5))-SPElimit*ones(1,6);
%     flag2=0;
%     for j2=1:6
%        if SPE_mw(i2,j2)<0
%            flag2=1;
%            i2=i2+j2;
%            break;
%        end
%    end
%    if flag2==0
%        detection_time_SPE=i2;
%        break;
%    end
% end
% detection_time_T2
% detection_time_SPE
% runtime=toc 
% %end