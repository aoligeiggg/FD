function [x, infos] = convex_mu_nmf(V, rank, in_options)
% (Kernel) Convex multiplicative update for non-negative matrix factorization ((Kernel-)Convex-MU-NMF).
%
% The problem of interest is defined as
%
%  (standard)   min || VWH - V ||_F^2,
%               where 
%               {W, H} >= 0, and 
%
%  (kernel)     min || K(V,V) WH - K(V,V) ||_F^2,
%               where 
%               {W, H} >= 0, and K(V,V) is a kernel matrix. 
%
%
% Given a V with mixed-signs, factorized non-negative matrices {W, H} are calculated.
%
%
% Inputs:
%       matrix      V
%       rank        rank
%       in_options 
%           sub_mode: 'std' (default) or 'kernel' 
%           kernel  : kernel type (rbf (default), polynomial, linear, sigmoid)
%           
% Output:
%       x           solution of x
%       infos       information
%
% References:
%       C. Ding, T. Li, and M.I. Jordan,
%       "Convex and semi-nonnegative matrix factorizations,"
%       IEEE Transations on Pattern Analysis and Machine Intelligence,
%       vol. 32, no. 1, pp. 45-55, 2010.
%
%       T. Li and C. Ding,
%       "The Relationships Among Various Nonnegative Matrix Factorization Methods for Clustering,"
%       International Conference on Data Mining,
%       2006.
%
%       Y. Li and A. Ngom,
%       "A New Kernel Non-Negative Matrix Factorization and Its Application in Microarray Data Analysis,"
%       CIBCB,
%       2012.
%    
%
% This file is part of NMFLibrary
%
% This file has been ported from 
% convexnmfrule.m and kernelconvexnmf.m at https://sites.google.com/site/nmftool/home/source-code
% by Yifeng Li.
%
%%%%
% Copyright (C) <2012>  <Yifeng Li>
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
% Contact Information:
% Yifeng Li
% University of Windsor
% li11112c@uwindsor.ca; yifeng.li.cn@gmail.com
% May 01, 2011
%%%%
%
%
% This file was originally created by Graham Grindla.
%
% 2010-01-14 Graham Grindlay (grindlay@ee.columbia.edu)
%
% Copyright (C) 2008-2028 Graham Grindlay (grindlay@ee.columbia.edu)
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
%
% Ported by H.Kasai on June 30, 2022
%
% Change log: 
%
    d00=importdata('d00.dat'); % 导入数据
    d01=importdata('d01_te.dat');
    V=d00;  %将d00的转置保存到变量X（训练集）52*500
    VT=d01';  %将d01保存到变量XT((测试集) 52*900
%     disp(size(V,2));
%     disp(size(VT,2));
% load('xjtu_train.mat');
% load('xjtu_test.mat');
% V = xjtu_train;
% VT = xjtu_test;

    % set dimensions and samples
    [m, n] = size(V);
    rank = 10;
    happen = 160;
    % set local options
    local_options = [];  
    local_options.sub_mode = 'std';
    local_options.kernel ='rbf';  
    local_options.kernel_param = []; 
    local_options.special_nmf_cost = @(V, W, H, R, options) convex_mu_nmf_cost_func(V, W, H, R, options);
    local_options.special_init_factors = @(V, rank, wh_flag, r_flag, options) convex_mu_initialize(V, rank, wh_flag, r_flag, options);    
    
    % check input options
    if ~exist('in_options', 'var') || isempty(in_options)
        in_options = struct();
    end     
    % merge options
    options = mergeOptions(get_nmf_default_options(), local_options);   
    options = mergeOptions(options, in_options);
    
    % initialize factors
    init_options = options;
    [init_factors, ~] = generate_init_factors(V, rank, init_options);    
    W = init_factors.W;
    H = init_factors.H; 

    % initialize
    epoch = 0; 
    grad_calc_count = 0;

    % initialize for this algorithm
    if strcmp(options.sub_mode, 'std')
        Ak = V' * V;
        X = V;  
        options.name = 'std';
    elseif strcmp(options.sub_mode, 'kernel')
        Ak = computeKernelMatrix(V, V, options);
        X = Ak;
        options.name = sprintf('kernel-%s', options.kernel);
    else
        error('Invalid sub_mode')
    end
    method_name = sprintf('Convex-MU (%s)', options.name);

    if options.verbose > 0
        fprintf('# %s: started ...\n', method_name);           
    end    

    Ap = (abs(Ak) + Ak) ./ 2;
    An = (abs(Ak) - Ak) ./ 2;
    
    % store initial info
    clear infos;
    [infos, f_val, optgap] = store_nmf_info(X, W, H, [], options, [], epoch, grad_calc_count, 0);
      
    if options.verbose > 1
        fprintf('Convex-MU (%s): Epoch = 0000, cost = %.16e, optgap = %.4e\n', options.name, f_val, optgap); 
    end     
         
    % set start time
    start_time = tic();

    % main loop
    while true
        
        % check stop condition
        [stop_flag, reason, max_reached_flag] = check_stop_condition(epoch, infos, options);
        if stop_flag
            display_stop_reason(epoch, infos, options, method_name, reason, max_reached_flag);
            break;
        end
        
        ApW = Ap * W;
        AnW = An * W;
        WH  = W * H;
   
        % update H
        H = H .* sqrt((ApW' + AnW' * WH) ./ (AnW' + ApW' * WH));
        H = max(H, eps);
        HHt = H * H';

        % update W
        W = W .* sqrt((Ap * H' + AnW * HHt) ./ (An * H' + ApW * HHt)); 
        W = max(W, eps);

        % measure gradient calc count
        grad_calc_count = grad_calc_count + m*n;

        % measure elapsed time
        elapsed_time = toc(start_time);        

        % update epoch
        epoch = epoch + 1;        
        
        % store info    
        infos = store_nmf_info(X, W, H, [], options, infos, epoch, grad_calc_count, elapsed_time);          
     
        % display info
        display_info(method_name, epoch, infos, options);

    end
    
    x.W = W;
    x.H = H;

end


function res = convex_mu_nmf_cost_func(V, W, H, R, options)

    res = norm(V - V * W * H, 'fro');

end


function [init_factors, init_factors_opts] = convex_mu_initialize(V, rank, wh_flag, r_flag, options)

    init_factors_opts = [];

    [~, n] = size(V);

    if wh_flag
        H = rand(rank, n);
        W = H' * diag(1./sum(H,2)');
    else
        W = options.x_init.W;
        H = options.x_init.H;       
    end

    init_factors.W = W;
    init_factors.H = H;   
    init_factors.R = zeros(size(V));
%% 以下是故障检测部分
    d01=importdata('d01_te.dat');
    VT=d01;%将d01保存到变量XT((测试集) 52*900
    X=V';% 52*500
    XT=VT;% 52*960
    disp (size(W,1));
    disp (size(H,1));
%% cg重构
     Hn= (pinv(W' * W))* W' * X;%Hn为重构的矩阵
     Xn= W * Hn;%52*500
%     disp(size(Xn,2));
%%
for i=1:size(X,2)
    t2(i) = transpose(Hn(:,i)) * H(:,i);%计算训练样本的异常指标，用于求控制限
    SPE(i) = transpose(X(:,i) - Xn(:,i)) * (X(:,i) - Xn(:,i));
end

% disp(size(W,2));
%% Compute Control limit of SPE and T2 计算控制限

    [bandwidth,density,xmesh,cdf]=kde(t2); %计算t2的控制限
    r=0.99;
    for i=1:size(cdf,1),
        if cdf(i,1)>=r,
            break;
        end;
    end;
    T2limit=xmesh(i);
    
    [bandwidth,density,xmesh,cdf]=kde(SPE); % 计算spe的控制限
    r=0.99;
    for i=1:size(cdf,1),
        if cdf(i,1)>=r,
            break;
        end;
    end;
    SPElimit= xmesh(i);
%% 固定W更新H
H = abs(randn(rank,size(VT,2)));
    % main loop
    while true
        
        % check stop condition
        [stop_flag, reason, max_reached_flag] = check_stop_condition(epoch, infos, options);
        if stop_flag
            display_stop_reason(epoch, infos, options, method_name, reason, max_reached_flag);
            break;
        end
        
        ApW = Ap * W;
        AnW = An * W;
        WH  = W * H;
   
        % update H
        H = H .* sqrt((ApW' + AnW' * WH) ./ (AnW' + ApW' * WH));
        H = max(H, eps);
        HHt = H * H';

%         % update W
%         W = W .* sqrt((Ap * H' + AnW * HHt) ./ (An * H' + ApW * HHt)); 
%         W = max(W, eps);

        % measure gradient calc count
        grad_calc_count = grad_calc_count + m*n;

        % measure elapsed time
        elapsed_time = toc(start_time);        

        % update epoch
        epoch = epoch + 1;        
        
        % store info    
        infos = store_nmf_info(X, W, H, [], options, infos, epoch, grad_calc_count, elapsed_time);          
     
        % display info
        display_info(method_name, epoch, infos, options);

    end  
%% cg重构
     Hne= (pinv(W' * W))* W' * XT;%Hne为固定W后重构的矩阵  
     Xne= W * Hne;%52*960
     %disp(size(Hne,1));
for i=1:size(XT,2)% i = 1:960
    XTt2(i) = transpose(Hne(:,i)) * Hne(:,i);%计算测试样本的异常指标 ***Hn的问题
    XTSPE(i) = transpose(XT(:,i) - Xne(:,i)) * (XT(:,i) - Xne(:,i));
end

%% Plot the results 绘制测试图形
figure(12)

subplot(2,1,1);
plot(1:happen,XTt2(1:happen),'b',happen+1:size(XTt2,2),XTt2(happen+1:end),'b');%绘制T2的值
hold on;
TS=T2limit*ones(size(XT,2),1);
plot(TS,'k--'); % 绘制控制限
title('测试集T2 for TE data');
xlabel('Sample');
ylabel('T2');
hold off;

subplot(2,1,2);
plot(1:happen,XTSPE(1:happen),'b',happen+1:size(XTSPE,2),XTSPE(happen+1:end),'b');%绘制SPE
hold on;
S=SPElimit*ones(size(XT,2),1);
plot(S,'k--');%绘制控制限
title('SPE for TE data');
xlabel('Sample');
ylabel('SPE');
hold off;


%% False alarm rate
falseT2=0;
falseSPE=0;
for wi=1:happen
    if XTt2(wi)>T2limit
        falseT2=falseT2+1;
    end
    falserate_DGE_T2=100*falseT2/happen;
    if XTSPE(wi)>SPElimit
        falseSPE=falseSPE+1;
    end
    falserate_DGE_SPE=100*falseSPE/happen;
end

%% Miss alarm rate and False alarm rate 计算误警率和漏警率
missT2=0;
missSPE=0;
for wi=happen+1:size(XTt2,2)
    if XTt2(wi)<T2limit
        missT2=missT2+1;
    end
    if XTSPE(wi)<SPElimit
        missSPE=missSPE+1;
    end 
end
missrate_DGE_T2=100*missT2/(size(XTt2,2)-happen);
missrate_DGE_SPE=100*missSPE/(size(XTt2,2)-happen);
 disp('----False alarm rate----');
falserate_DGE = [falserate_DGE_T2 falserate_DGE_SPE]
 disp('----Miss alarm rate----');
missrate_DGE = [missrate_DGE_T2 missrate_DGE_SPE]
% % toc
% 
% %% Detection time 计算检测时间和运行时间
% i1=happen+1;
% while i1<=size(X,1)
%    T2_mw(i1,:)=XTt2(1,i1:(i1+5))-T2limit*ones(1,6);
%    flag1=0;
%    for j1=1:6
%        if T2_mw(i1,j1)<0
%            flag1=1;
%            i1=i1+j1;
%            break;
%        end
%    end
%    if flag1==0
%        detection_time_T2=i1;
%        break;
%    end
% end
% i2=happen+1;
% while i2<=size(X,1)
%     SPE_mw(i2,:)= XTSPE(1,i2:(i2+5))-SPElimit*ones(1,6);
%     flag2=0;
%     for j2=1:6
%        if SPE_mw(i2,j2)<0
%            flag2=1;
%            i2=i2+j2;
%            break;
%        end
%    end
%    if flag2==0
%        detection_time_SPE=i2;
%        break;
%    end
% end
% detection_time_T2
% detection_time_SPE
% runtime=toc 

end
